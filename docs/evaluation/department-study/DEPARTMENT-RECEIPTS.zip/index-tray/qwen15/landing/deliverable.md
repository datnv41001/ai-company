# Khay chia linh kiện Khe Gọn - Vách ngăn tháo rời, giá ưu đãi

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi.

Khay chia linh kiện Khe Gọn có thể tháo rời, phù hợp với mẫu tiêu chuẩn. Giá 380.000 VND cho 1 box (含 thuế). Xác nhận số lượng trước khi đặt.

Vách ngăn có thể tháo rời Áp dụng cho mẫu tiêu chuẩn.
Giá tham khảo: 380.000 VND / 1 hộp, đã gồm thuế. Đơn tối thiểu: 1 hộp. Áp dụng từ 1 hộp. Số lượng đối chiếu: 1 hộp. Xác nhận số lượng trước khi đặt.

Yêu cầu báo giá

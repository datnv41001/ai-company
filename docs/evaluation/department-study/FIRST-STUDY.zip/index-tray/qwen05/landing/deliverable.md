# Khay chia linh kiện Khe Gọn

Vách ngăn có thể tháo rời với giá VND 380,000 / 1 box (tax included).

Khay chia linh kiện Khe Gọn có thể tháo rời với giá VND 380,000 / 1 box (tax included).

Vách ngăn có thể tháo rời Áp dụng cho mẫu tiêu chuẩn.
Giá tham khảo: 380.000 VND / 1 hộp, đã gồm thuế. Đơn tối thiểu: 1 hộp. Áp dụng từ 1 hộp. Số lượng đối chiếu: 1 hộp. Xác nhận số lượng trước khi đặt.

Yêu cầu báo giá

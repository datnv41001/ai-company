## Rubric khóa trước khi chạy

Mỗi gói chấm tám tiêu chí bên dưới, mỗi tiêu chí 0–2. 0 là thiếu hoặc mâu thuẫn, 1 là có nội dung nhưng người làm tiếp còn phải bổ sung thông tin, 2 là có căn cứ và người nhận có thể hành động. Người chấm dẫn nguyên văn trường liên quan và nêu phần cần biên tập. Một tuyên bố thương mại trái nguồn, nhầm hành động người mua hoặc bỏ điều kiện trọng yếu là blocker, không bù bằng điểm tổng. Giữ báo cáo kỹ thuật tự động và kết luận nghề nghiệp riêng.

| Tiêu chí | Điều người chấm phải đối chiếu |
|---|---|
| Người mua & thị trường | Phân khúc, vấn đề cần xác minh, câu hỏi hoặc phép thử có thể thực hiện. |
| Định vị | Giá trị gắn với tình huống của người mua và dữ kiện có thể kiểm chứng. |
| Chiến lược | Lựa chọn hành động/kênh có lý do, bước tiếp theo sau kết quả thử. |
| Landing | Lời mời phù hợp brief, thông tin cần cung cấp, điều kiện giá/đơn vị và ranh giới claim. |
| SEO | Title, intent và mô tả khớp trang, ngôn ngữ và nhu cầu tìm kiếm. |
| Social | Mở bài, giá trị, lời mời phù hợp hoàn cảnh đọc; không dùng lời hứa thiếu bằng chứng. |
| Quảng cáo | Message ngắn có sự khác biệt với bài xã hội, liên kết đúng offer và bước tiếp theo. |
| Đo lường | Biến cố và mẫu số, kỳ quan sát, trách nhiệm đối soát, xử lý thiếu nguồn hoặc hủy. |

Chấm toàn bộ gói ở lần đầu và bản dùng được sau QA. Đối chiếu các trường giữ nguyên văn với receipt của model. Kiểm tra riêng tính nhất quán giữa các tài sản và ghi rõ khi một câu lặp qua các kênh. Một cặp brief chỉ cung cấp tín hiệu định tính, chưa đủ để ước lượng hiệu quả thực tế hoặc mức sẵn sàng thương mại. Thử nghiệm thủ công có đồng thuận với người làm Marketing, reviewer và Sales/owner dùng cùng bộ brief và rubric.


## Doanh nghiệp

Xưởng Nhịp Kho

## Thương hiệu

Khe Gọn

## Sản phẩm hoặc dịch vụ

Khay chia linh kiện Khe Gọn

## sku

KG-P

## Người mua

Tổ trưởng lắp ráp điện tử

## Mục tiêu

Nhận yêu cầu báo giá khay chia linh kiện theo hộp cho bàn lắp ráp

## Hành động mục tiêu

rfq

## Chỉ số kết quả

Yêu cầu có số hộp, địa bàn và thời điểm cần hàng

## Cách đo

Đếm yêu cầu báo giá đủ ba thông tin trên số phiên vào trang rồi đối soát mã yêu cầu với Sales.

## Kỳ đo

21 ngày

## Giả thuyết

- Người phụ trách có thể cần chia vách theo công đoạn; phải phỏng vấn để xác minh.

## Giới hạn tuyên bố

- Không suy diễn chứng nhận an toàn điện hoặc công bố mức giảm thời gian lắp ráp.

## Bước người mua cần làm

Yêu cầu báo giá theo hộp và ghi số hộp, địa bàn, thời điểm cần hàng.

## Mô tả được duyệt

Vách ngăn có thể tháo rời. Áp dụng cho mẫu tiêu chuẩn.

## Giá và điều kiện được duyệt

380000 VND / 1 box; gồm thuế. Xác nhận số lượng trước khi đặt.
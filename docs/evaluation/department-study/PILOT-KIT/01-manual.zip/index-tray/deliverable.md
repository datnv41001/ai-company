# Bản bàn giao của người làm Marketing

## buyer_market

## positioning

## strategy

## landing

## seo

## social

## ad

## measurement
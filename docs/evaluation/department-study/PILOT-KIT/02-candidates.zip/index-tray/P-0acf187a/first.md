## Kế hoạch chiến dịch

### Người mua

Tổ trưởng lắp ráp điện tử

### Mục tiêu

Nhận yêu cầu báo giá khay chia linh kiện theo hộp cho bàn lắp ráp

### Hành động mục tiêu

rfq

### target outcome

Nhận yêu cầu báo giá khay chia linh kiện theo hộp cho bàn lắp ráp

### channels

- web

### research gaps

- Kiểm chứng nhu cầu với khách hàng trong thị trường đã chọn.
- Xác minh số liệu nền và kết quả bằng dữ liệu đo thực tế.

### measurement plan

#### Chỉ số kết quả

Yêu cầu có số hộp, địa bàn và thời điểm cần hàng · requests · 21 ngày · Đếm yêu cầu báo giá đủ ba thông tin trên số phiên vào trang rồi đối soát mã yêu cầu với Sales.

#### hypothesis

Thử một CTA cho Tổ trưởng lắp ráp điện tử rồi đối soát với kết quả Sales.

#### attribution

Theo mã yêu cầu và biên nhận, ghi riêng kết quả thiếu nguồn.

#### Hành động mục tiêu

rfq

### work packages

- #### id

strategy

#### kind

strategy

#### role

Strategy

#### due day

7

#### criteria

Quyết định phân khúc, kênh và bước xử lý tiếp theo

#### complexity

multi_section
- #### id

measurement

#### kind

measurement

#### role

Analytics

#### due day

7

#### criteria

KPI, mẫu số và phương pháp đối soát Sales

#### complexity

multi_section
- #### id

landing

#### kind

landing

#### role

Content

#### due day

14

#### criteria

Nội dung trang có CTA và điều kiện theo manifest

#### complexity

multi_section
- #### id

seo

#### kind

seo

#### role

SEO

#### due day

14

#### criteria

Tiêu đề SEO và mô tả khớp trang

#### complexity

single_asset
- #### id

social

#### kind

social

#### role

Social

#### due day

14

#### criteria

Bài xã hội có hành động nhất quán với brief

#### complexity

single_asset
- #### id

ad

#### kind

ad

#### role

Media

#### due day

14

#### criteria

Mẫu quảng cáo nháp cho người mua đã chọn

#### complexity

single_asset
- #### id

creative_brief

#### kind

creative_brief

#### role

Design

#### due day

14

#### criteria

Brief nêu sản phẩm, người xem và tiêu chí hình ảnh

#### complexity

single_asset
- #### id

calendar

#### kind

calendar

#### role

Campaign Manager

#### due day

21

#### criteria

Lịch dự kiến có người nhận, mốc QA và kênh

#### complexity

multi_channel

## Nội dung theo kênh

### Bài mạng xã hội

Đây là một bài mạng xã hội và một mẫu quảng cáo bằng tiếng Việt cho brief này. Hai kênh cần có góc mở bài khác nhau và hành động đúng mục tiêu. Chỉ dùng thông tin thương mại trong facts với đầy đủ điều kiện. Giữ ý kiến, giả thuyết và dữ kiện riêng. Không thêm chứng nhận, cam kết,

### Nội dung quảng cáo

Vách ngăn có thể tháo rời với giá VND 380,000 / 1 box (tax included). Khay chia linh kiện Khe Gọn có thể tháo rời với giá VND 380,000 / 1 box (tax included). Yêu cầu báo giá. Yêu cầu có số hộp, địa bàn và thời điểm cần hàng. Yêu cầu báo giá theo hộp và ghi số hộp, địa bàn, thời g

### Brief thiết kế

Thiết kế cho Tổ trưởng lắp ráp điện tử trên web. Đặt Khay chia linh kiện Khe Gọn ở vị trí chính và dùng CTA “Yêu cầu báo giá”. Giọng điệu: Nêu đúng điều kiện, không suy diễn chứng nhận hoặc mức tiết kiệm. Kiểm tra quyền sử dụng hình ảnh trước bàn giao.

### Lịch công việc

Ngày 7 · Strategy · Quyết định phân khúc, kênh và bước xử lý tiếp theo
Ngày 7 · Analytics · KPI, mẫu số và phương pháp đối soát Sales
Ngày 14 · Content · Nội dung trang có CTA và điều kiện theo manifest
Ngày 14 · SEO · Tiêu đề SEO và mô tả khớp trang
Ngày 14 · Social · Bài xã hội có hành động nhất quán với brief
Ngày 14 · Media · Mẫu quảng cáo nháp cho người mua đã chọn
Ngày 14 · Design · Brief nêu sản phẩm, người xem và tiêu chí hình ảnh
Ngày 21 · Campaign Manager · Lịch dự kiến có người nhận, mốc QA và kênh
Kênh đề xuất: web. Điểm duyệt: kiểm tra chứng cứ và phê duyệt từng tài sản trước thực thi.

## Chiến lược

### Nghiên cứu

#### buyer problem

Người phụ trách có thể cần chia vách theo công đoạn

#### research question

Khay chia linh kiện Khe Gọn có thể tháo rời không?

#### evidence

Vách ngăn có thể tháo rời Áp dụng cho mẫu tiêu chuẩn.
Giá tham khảo: 380.000 VND / 1 hộp, đã gồm thuế. Đơn tối thiểu: 1 hộp. Áp dụng từ 1 hộp. Số lượng đối chiếu: 1 hộp. Xác nhận số lượng trước khi đặt.

#### hypothesis

Giả thuyết cần thử: làm rõ điều kiện của Khay chia linh kiện Khe Gọn giúp Tổ trưởng lắp ráp điện tử chọn bước tiếp theo.

### Chiến lược

#### positioning

Khay chia linh kiện Khe Gọn có thể tháo rời không?

#### channel choice

web

#### rationale

Khay chia linh kiện Khe Gọn có thể tháo rời không?
Người phụ trách có thể cần chia vách theo công đoạn
Tổ trưởng lắp ráp điện tử
Người phụ trách có thể cần chia vách theo công đoạn

#### execution

Soạn hai phiên bản giới thiệu Khay chia linh kiện Khe Gọn trên web, giữ nguyên điều kiện và đo cùng một hành động.

### Đo lường

#### test hypothesis

Người phụ trách có thể cần chia vách theo công đoạn

#### measurable action

Yêu cầu báo giá

#### measurement method

11 ngày, 21 ngày, 1 tháng, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm, 1 năm

### Chiến lược giao doanh nghiệp

#### target

Tổ trưởng lắp ráp điện tử

#### decision

Đề xuất giúp Tổ trưởng lắp ráp điện tử đối chiếu quy cách của Khay chia linh kiện Khe Gọn trước khi gửi yêu cầu báo giá.

#### activation

Trên web, đặt điều kiện áp dụng cạnh lời mời báo giá. Chuyển yêu cầu đủ thông tin cho Sales.

#### next decision

Nếu nhiều người gửi nhưng Sales còn phải hỏi lại, ưu tiên sửa trường thông tin thiếu trước khi mở rộng kênh.

### Đo lường giao doanh nghiệp

#### hypothesis

Thử đặt quy cách trước biểu mẫu để người mua có thể gửi yêu cầu đủ thông tin hơn.

#### conversion

Yêu cầu báo giá

#### method

Đối soát mã yêu cầu duy nhất với yêu cầu Sales đủ thông tin để báo giá. So sánh trên lượt vào trang cùng nhóm khách.

## Trang đích và tìm kiếm

### Nội dung trang

#### Tiêu đề

Khay chia linh kiện Khe Gọn

#### Giá trị đề xuất

Vách ngăn có thể tháo rời với giá VND 380,000 / 1 box (tax included).

#### Lợi ích

Khay chia linh kiện Khe Gọn có thể tháo rời với giá VND 380,000 / 1 box (tax included).

#### Điều kiện thương mại

Vách ngăn có thể tháo rời Áp dụng cho mẫu tiêu chuẩn.
Giá tham khảo: 380.000 VND / 1 hộp, đã gồm thuế. Đơn tối thiểu: 1 hộp. Áp dụng từ 1 hộp. Số lượng đối chiếu: 1 hộp. Xác nhận số lượng trước khi đặt.

#### Lời mời hành động

Yêu cầu báo giá

### SEO

#### Tiêu đề tìm kiếm

Khay chia linh kiện Khe Gọn

#### Mô tả tìm kiếm

Khay chia linh kiện Khe Gọn có thể tháo rời với giá VND 380,000 / 1 box (tax included). RFQ for Khay chia linh kiện Khe Gọn.

#### Nhu cầu tìm kiếm

RFQ
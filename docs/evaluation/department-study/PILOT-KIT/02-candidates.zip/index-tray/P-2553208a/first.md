## Kế hoạch chiến dịch

### Người mua

Tổ trưởng lắp ráp điện tử

### Mục tiêu

Nhận yêu cầu báo giá khay chia linh kiện theo hộp cho bàn lắp ráp

### Hành động mục tiêu

rfq

### target outcome

Nhận yêu cầu báo giá khay chia linh kiện theo hộp cho bàn lắp ráp

### channels

- web

### research gaps

- Kiểm chứng nhu cầu với khách hàng trong thị trường đã chọn.
- Xác minh số liệu nền và kết quả bằng dữ liệu đo thực tế.

### measurement plan

#### Chỉ số kết quả

Yêu cầu có số hộp, địa bàn và thời điểm cần hàng · requests · 21 ngày · Đếm yêu cầu báo giá đủ ba thông tin trên số phiên vào trang rồi đối soát mã yêu cầu với Sales.

#### hypothesis

Thử một CTA cho Tổ trưởng lắp ráp điện tử rồi đối soát với kết quả Sales.

#### attribution

Theo mã yêu cầu và biên nhận, ghi riêng kết quả thiếu nguồn.

#### Hành động mục tiêu

rfq

### work packages

- #### id

strategy

#### kind

strategy

#### role

Strategy

#### due day

7

#### criteria

Quyết định phân khúc, kênh và bước xử lý tiếp theo

#### complexity

multi_section
- #### id

measurement

#### kind

measurement

#### role

Analytics

#### due day

7

#### criteria

KPI, mẫu số và phương pháp đối soát Sales

#### complexity

multi_section
- #### id

landing

#### kind

landing

#### role

Content

#### due day

14

#### criteria

Nội dung trang có CTA và điều kiện theo manifest

#### complexity

multi_section
- #### id

seo

#### kind

seo

#### role

SEO

#### due day

14

#### criteria

Tiêu đề SEO và mô tả khớp trang

#### complexity

single_asset
- #### id

social

#### kind

social

#### role

Social

#### due day

14

#### criteria

Bài xã hội có hành động nhất quán với brief

#### complexity

single_asset
- #### id

ad

#### kind

ad

#### role

Media

#### due day

14

#### criteria

Mẫu quảng cáo nháp cho người mua đã chọn

#### complexity

single_asset
- #### id

creative_brief

#### kind

creative_brief

#### role

Design

#### due day

14

#### criteria

Brief nêu sản phẩm, người xem và tiêu chí hình ảnh

#### complexity

single_asset
- #### id

calendar

#### kind

calendar

#### role

Campaign Manager

#### due day

21

#### criteria

Lịch dự kiến có người nhận, mốc QA và kênh

#### complexity

multi_channel

## Nội dung theo kênh

### Bài mạng xã hội

Khay chia linh kiện Khe Gọn - Vách ngăn tháo rời, giá ưu đãi

Vách ngăn có thể tháo rời, phù hợp với mẫu tiêu chuẩn. Giá 380.000 VND cho 1 box (含 thuế). Xác nhận số lượng trước khi đặt.

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi.

Khá

### Nội dung quảng cáo

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi.

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi.

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi.

Khay chia,

### Brief thiết kế

Thiết kế cho Tổ trưởng lắp ráp điện tử trên web. Đặt Khay chia linh kiện Khe Gọn ở vị trí chính và dùng CTA “Yêu cầu báo giá”. Giọng điệu: Nêu đúng điều kiện, không suy diễn chứng nhận hoặc mức tiết kiệm. Kiểm tra quyền sử dụng hình ảnh trước bàn giao.

### Lịch công việc

Ngày 7 · Strategy · Quyết định phân khúc, kênh và bước xử lý tiếp theo
Ngày 7 · Analytics · KPI, mẫu số và phương pháp đối soát Sales
Ngày 14 · Content · Nội dung trang có CTA và điều kiện theo manifest
Ngày 14 · SEO · Tiêu đề SEO và mô tả khớp trang
Ngày 14 · Social · Bài xã hội có hành động nhất quán với brief
Ngày 14 · Media · Mẫu quảng cáo nháp cho người mua đã chọn
Ngày 14 · Design · Brief nêu sản phẩm, người xem và tiêu chí hình ảnh
Ngày 21 · Campaign Manager · Lịch dự kiến có người nhận, mốc QA và kênh
Kênh đề xuất: web. Điểm duyệt: kiểm tra chứng cứ và phê duyệt từng tài sản trước thực thi.

## Chiến lược

### Nghiên cứu

#### buyer problem

Người phụ trách cần chia vách ngăn theo công đoạn trong quá trình lắp ráp điện tử.

#### research question

Nhu cầu chia vách ngăn theo công đoạn trong quá trình lắp ráp điện tử của tổ trưởng lắp ráp điện tử là gì?

#### evidence

Vách ngăn có thể tháo rời Áp dụng cho mẫu tiêu chuẩn.
Giá tham khảo: 380.000 VND / 1 hộp, đã gồm thuế. Đơn tối thiểu: 1 hộp. Áp dụng từ 1 hộp. Số lượng đối chiếu: 1 hộp. Xác nhận số lượng trước khi đặt.

#### hypothesis

Giả thuyết cần thử: làm rõ điều kiện của Khay chia linh kiện Khe Gọn giúp Tổ trưởng lắp ráp điện tử chọn bước tiếp theo.

### Chiến lược

#### positioning

The product 'Khay chia linh kiện Khe Gọn' is designed to be reusable and can be easily removed, which is suitable for the production process of electronic assembly.

#### channel choice

web

#### rationale

The task is to design a bounded test for the positioning of the product 'Khay chia linh kiện Khe Gọn' and define its metric. The provided information includes product details, audience, facts, and a K

#### execution

Soạn hai phiên bản giới thiệu Khay chia linh kiện Khe Gọn trên web, giữ nguyên điều kiện và đo cùng một hành động.

### Đo lường

#### test hypothesis

The product 'Khay chia linh kiện Khe Gọn' can be reused and easily removed, which is suitable for the production process of electronic assembly.

#### measurable action

Yêu cầu báo giá

#### measurement method

The product 'Khay chia linh kiện Khe Gọn' can be reused and easily removed, which is suitable for the production process of electronic assembly.

### Chiến lược giao doanh nghiệp

#### target

Tổ trưởng lắp ráp điện tử

#### decision

Đề xuất giúp Tổ trưởng lắp ráp điện tử đối chiếu quy cách của Khay chia linh kiện Khe Gọn trước khi gửi yêu cầu báo giá.

#### activation

Trên web, đặt điều kiện áp dụng cạnh lời mời báo giá. Chuyển yêu cầu đủ thông tin cho Sales.

#### next decision

Nếu nhiều người gửi nhưng Sales còn phải hỏi lại, ưu tiên sửa trường thông tin thiếu trước khi mở rộng kênh.

### Đo lường giao doanh nghiệp

#### hypothesis

Thử đặt quy cách trước biểu mẫu để người mua có thể gửi yêu cầu đủ thông tin hơn.

#### conversion

Yêu cầu báo giá

#### method

Đối soát mã yêu cầu duy nhất với yêu cầu Sales đủ thông tin để báo giá. So sánh trên lượt vào trang cùng nhóm khách.

## Trang đích và tìm kiếm

### Nội dung trang

#### Tiêu đề

Khay chia linh kiện Khe Gọn - Vách ngăn tháo rời, giá ưu đãi

#### Giá trị đề xuất

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi.

#### Lợi ích

Khay chia linh kiện Khe Gọn có thể tháo rời, phù hợp với mẫu tiêu chuẩn. Giá 380.000 VND cho 1 box (含 thuế). Xác nhận số lượng trước khi đặt.

#### Điều kiện thương mại

Vách ngăn có thể tháo rời Áp dụng cho mẫu tiêu chuẩn.
Giá tham khảo: 380.000 VND / 1 hộp, đã gồm thuế. Đơn tối thiểu: 1 hộp. Áp dụng từ 1 hộp. Số lượng đối chiếu: 1 hộp. Xác nhận số lượng trước khi đặt.

#### Lời mời hành động

Yêu cầu báo giá

### SEO

#### Tiêu đề tìm kiếm

Khay Chia Linh kiện Khe Gọn - Vách ngăn Tháo Rời, Giá Uy Tín

#### Mô tả tìm kiếm

Khay chia linh kiện Khe Gọn, vách ngăn tháo rời, phù hợp với mẫu tiêu chuẩn, giá ưu đãi. Khay chia linh kiện Khe Gọn có thể tháo rời, giá 380.000 VND cho 1 box (含 thuế). Xác nhận số lượng trước khi下单.

#### Nhu cầu tìm kiếm

inform
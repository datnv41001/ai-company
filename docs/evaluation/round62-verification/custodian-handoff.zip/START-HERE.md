# Bàn giao O-09 cho custodian

Trạng thái **chưa niêm phong**. Checkout giao thức: https://github.com/datnv41001/ai-company/blob/365cdbbfb44f2360a91c9ea88e83040284bb60ac/docs/evaluation/round62/BENCHMARK.md.
Đọc BENCHMARK.md trước khi điền biểu mẫu. Bốn tệp JSON là mẫu trắng. Chỉ điền bản riêng sau khi người có thẩm quyền đã cấp vault và kiểm thử quyền. Tạo 12 họ mới, mỗi họ có VI/EN; custodian giữ gold, mapping, rubric kín và nonce ngoài quyền developer. Người giữ digest độc lập ký nhận trước khi chạy hai control và candidate. Chưa có prediction hoặc kết quả holdout trong gói này.

# Independent AI review · Research and Strategy first drafts

Read the source packet for each pair. Score both drafts independently using the rubric below. The recorded Director choices supply context; the two specialist stages are the editing unit. Source packets and outputs are synthetic. Keep the original response texts, including unusual phrasing. Missing downstream work is identified explicitly. Fill SCORES.json, cite each meaningful correction and avoid counting two corrections to one field twice. Indicate AI reviewer status and potential uncertainty. Lock the returned file (SHA-256) before requesting the assignment key. No paid service, external action or practitioner time measurement is part of this packet.

Score the first Research and Strategy outputs jointly on the six dimensions below. For each, record **0** for a missing or materially wrong obligation, **1** for partially right but needing substantial revision, **2** for adequate fixture-specific professional work. Cite a field, source handle or exact brief condition and say what correction would change the score.

| Dimension | Question for the reviewer |
|---|---|
| Segment and decision maker | Does the draft identify who decides, their purchasing situation and constraint? Is geography used accurately? |
| Facts, observations, hypotheses | Does it preserve qualifiers and sample limits, and mark an inference as an inference? |
| Research question and evidence | Could the proposed evidence answer the question and change the decision? What evidence is still missing? |
| Positioning, rationale, action | Is there a supported differentiator or choice relevant to this buyer, with a reason and practical next action? |
| Measurable action and method | Is the event distinct from how it will be counted, qualified, deduplicated and checked in its window? |
| Cross-stage consistency | Does Strategy use the actual Research result and respect brief, authority, terms and scope? |

Flag hard failures separately: claim contradicted by a source, unauthorized decision or action, invented or altered commercial terms, lost material constraint. Mark unsupported assertions separately from directly contradicted ones. Count **one meaningful edit per distinct Research/Strategy output field** needing a change to meaning, evidence, decision, terms, eligibility or measurement. Cite role.field and the proposed correction. Several problems in one field count once. Cosmetic rewrites count zero. A missing required field counts once when a draft exists. Do not impute edit counts to a missing stage; a complete pair requires two valid stage chains. Technical/schema checks are separate from these scores.

Each pair is scored before comparing sides. Record ties and disagreements.

# Bộ đề landing QA

## LOOM

**Mục tiêu** Introduce a waterproof pannier for commuters cycling to work.
**Đối tượng** bicycle commuters
**Đề nghị** waterproof pannier
**Hướng dẫn thương hiệu** Our voice is calm and practical. Calling the bag indestructible would contradict the repair guide; leave that word out of customer copy.

- **brand · Brand Kit** The pannier attaches to a bicycle rack. The seam is waterproof.
- **S1 · Thông tin sản phẩm mẫu** The bag holds 12 litres.
- **S2 · Lời nhận xét mẫu** In a fictional rider survey, one person wrote: “The best bag.” The survey tested no competing models.

### L01 · content

Nguồn đã dẫn · brand

- **headline** Túi treo xe đạp đi làm
- **body_copy** Người đạp xe đến văn phòng có thể gắn túi chống nước vào baga.
- **call_to_action** Xem mẫu túi

### L02 · content

Nguồn đã dẫn · brand

- **headline** Pannier for bicycle commuters
- **body_copy** This indestructible pannier clips onto a bicycle rack.
- **call_to_action** See the fitting guide

### L03 · content

Nguồn đã dẫn · S1

- **headline** Pannier for bicycle commuters
- **body_copy** The bag holds 12 litres.
- **call_to_action** The bag holds 12 litres.

### L04 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · L01

- **page_title** Bicycle bags for the ride to work
- **meta_description** Choose a waterproof cycle bag for the daily trip to the office.
- **search_intent** waterproof rack bag for commuters

### L05 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · L02

- **page_title** Bicycle pannier fitting guide
- **meta_description** Compare espresso machines and grinders in this home brewing guide.
- **search_intent** which grinder for espresso

### L06 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · L03

- **page_title** Pannier
- **meta_description** Pannier
- **search_intent** commuter pannier

## CLAY

**Mục tiêu** Mời người mới đến lớp làm gốm cuối tuần.
**Đối tượng** người mới học gốm
**Đề nghị** lớp làm gốm có người hướng dẫn
**Hướng dẫn thương hiệu** Tránh: thần kỳ. Viết gần gũi, tôn trọng tốc độ học riêng của mỗi người.

- **brand · Brand Kit** Lớp gốm có người hướng dẫn và bàn xoay dùng chung.
- **S1 · Thông tin sản phẩm mẫu** Buổi thực hành kéo dài 90 phút.
- **S2 · Lời nhận xét mẫu** Một học viên mô tả cảm nhận cá nhân. Lớp không tổ chức đánh giá tốc độ tiến bộ.

### C01 · content

Nguồn đã dẫn · brand

- **headline** Xoay đất cuối tuần
- **body_copy** Người mới học gốm làm quen với bàn xoay cùng người hướng dẫn.
- **call_to_action** Giữ chỗ cho buổi học

### C02 · content

Nguồn đã dẫn · brand

- **headline** Lớp gốm cuối tuần
- **body_copy** Lớp gốm dành cho người mới. Chúng tôi không cam kết hiệu quả 100%.
- **call_to_action** Đăng ký lớp gốm

### C03 · content

Nguồn đã dẫn · brand

- **headline** Thần kỳ với bàn xoay
- **body_copy** Người mới học gốm được hướng dẫn tại bàn xoay.
- **call_to_action** Đọc lịch học

### C04 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · C01

- **page_title** Buổi tập nặn đất cho người bắt đầu
- **meta_description** Tự tay tạo chiếc bát đầu tiên trong buổi học có người hướng dẫn.
- **search_intent** lớp làm gốm cho người mới

### C05 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · C01

- **page_title** Bàn xoay công nghiệp đã qua sử dụng
- **meta_description** Mua máy công nghiệp thanh lý cho nhà xưởng đang tăng sản lượng.
- **search_intent** mua máy bàn xoay công nghiệp

### C06 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · C03

- **page_title** Lớp gốm cuối tuần cho người mới
- **meta_description** Lớp gốm này thu hút 900 lượt tìm kiếm mỗi ngày.
- **search_intent** lớp gốm có người hướng dẫn

## BEAN

**Mục tiêu** Help home brewers choose a reusable coffee filter.
**Đối tượng** home coffee brewers
**Đề nghị** reusable coffee filter
**Hướng dẫn thương hiệu** Avoid: flawless. Use everyday language.

- **brand · Brand Kit** The reusable steel coffee filter fits a cone dripper.
- **S1 · Thông tin sản phẩm mẫu** Rinse the filter after brewing.
- **S2 · Lời nhận xét mẫu** One guest shared a preference. The best coffee. The comment was about the café's beans, not this filter.

### B01 · content

Nguồn đã dẫn · brand, S1

- **headline** Reusable coffee filter for home brewers
- **body_copy** A steel coffee filter can be rinsed after brewing.
- **call_to_action** Compare filter shapes

### B02 · content

Nguồn đã dẫn · S2

- **headline** Reusable coffee filter for home brewers
- **body_copy** The best coffee.
- **call_to_action** See the steel filter

### B03 · content

Nguồn đã dẫn · brand

- **headline** Summer tickets for concert fans
- **body_copy** Concert fans can reserve a seat at the outdoor jazz festival.
- **call_to_action** Book a seat

### B04 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · B01

- **page_title** Reusable coffee filters for home
- **meta_description** Reusable coffee filters for home
- **search_intent** reusable coffee filter

### B05 · seo

Nguồn đã dẫn · brand, S1
Trang Content tiền nhiệm · B01

- **page_title** Coffee filter care for home brewers
- **meta_description** There is no guarantee of 100% sediment removal when brewing at home.
- **search_intent** how to clean a reusable coffee filter

### B06 · seo

Nguồn đã dẫn · brand, S1
Trang Content tiền nhiệm · B01

- **page_title** Cách pha cà phê bằng phễu lọc thép
- **meta_description** Chọn bộ lọc tái sử dụng để pha cà phê tại nhà và rửa sau mỗi lần pha.
- **search_intent** bộ lọc kim loại dùng lại cho cà phê

## GLOW

**Mục tiêu** Present an evening tour of an imaginary lighthouse for families.
**Đối tượng** families with children
**Đề nghị** evening lighthouse tour
**Hướng dẫn thương hiệu** Describe the tower through sounds and textures. Our editors leave out claims about being the best in town.

- **brand · Brand Kit** Families visit the lighthouse gallery with a guide. The route ends in the lower gallery.
- **S1 · Thông tin sản phẩm mẫu** Children can touch the replica lens. The original lens is behind glass.
- **S2 · Lời nhận xét mẫu** One visitor preferred the lower gallery. No ranking or popularity survey exists.

### G01 · content

Nguồn đã dẫn · brand, S1

- **headline** Evening lighthouse tour for families
- **body_copy** Families can feel the replica lens in the lighthouse gallery.
- **call_to_action** Reserve your family visit

### G02 · content

Nguồn đã dẫn · S1, brand

- **headline** Evening lighthouse tour for families
- **body_copy** Families can touch the original lens in the lighthouse gallery.
- **call_to_action** Book an evening tour

### G03 · content

Nguồn đã dẫn · brand

- **headline** A lighthouse evening for procurement teams
- **body_copy** Procurement managers join the evening lighthouse tour to discuss supply contracts.
- **call_to_action** Book an evening tour

### G04 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · G01

- **page_title** Evening lighthouse tour for families
- **meta_description** Families visit the lighthouse gallery with a guide after dusk.
- **search_intent** lighthouse evening tour with children

### G05 · seo

Nguồn đã dẫn · S2
Trang Content tiền nhiệm · G01

- **page_title** Night at the lighthouse gallery
- **meta_description** The best lighthouse in town for family visits.
- **search_intent** evening lighthouse tour for families

### G06 · seo

Nguồn đã dẫn · brand
Trang Content tiền nhiệm · G01

- **page_title** Evening lighthouse tour for families
- **meta_description** Families can visit the lighthouse gallery on an evening tour.
- **search_intent** family property for sale near a lighthouse

